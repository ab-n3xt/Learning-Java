package recipes.Recipe;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class RecipeService {

    private final RecipeRepo repository;

    @Autowired
    public RecipeService(RecipeRepo repository) {
        this.repository = repository;
    }

    public Recipe getRecipe(long id) {
        Optional<Recipe> recipe = repository.findById(id);

        if (recipe.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        else {
            return recipe.get();
        }
    }

    public long setRecipe(Recipe recipe) {
        Recipe storedRecipe = repository.save(recipe);
        return storedRecipe.getId();
    }

    public boolean deleteRecipe(long id) {
        if (getRecipe(id) != null) {
            repository.deleteById(id);
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateRecipe(long id, Recipe recipe) {
        if (getRecipe(id) != null) {
            Recipe recipeFromDB = getRecipe(id);

            // Update all values
            recipeFromDB.setName(recipe.getName());
            recipeFromDB.setCategory(recipe.getCategory());
            recipeFromDB.setDate(new Date());
            recipeFromDB.setIngredients(recipe.getIngredients());
            recipeFromDB.setDescription(recipe.getDescription());
            recipeFromDB.setDirections(recipe.getDirections());

            return true;
        }
        else {
            return false;
        }
    }

    public List<Recipe> getRecipesByCategory(String category) {
        return this.repository.findByCategoryIgnoreCaseOrderByDateDesc(category);
    }

    public List<Recipe> getRecipesByName(String name) {
        return this.repository.findByNameIgnoreCaseContainingOrderByDateDesc(name);
    }
}
