package recipes.Recipe;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.transaction.Transactional;
import java.util.Optional;

@Service
@Transactional
public class RecipeService {

    private final RecipeRepo repository;

    @Autowired
    public RecipeService(RecipeRepo repository) {
        this.repository = repository;
    }

    public Recipe getRecipe(long id) {
        Optional<Recipe> recipe = repository.findById(id);

        if (recipe.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        else {
            return recipe.get();
        }
    }

    public long setRecipe(Recipe recipe) {
        Recipe storedRecipe = repository.save(recipe);
        return storedRecipe.getId();
    }

    public boolean deleteRecipe(long id) {
        if (getRecipe(id) != null) {
            repository.deleteById(id);
            return true;
        }
        else {
            return false;
        }
    }
}
