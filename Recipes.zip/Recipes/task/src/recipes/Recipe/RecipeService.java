package recipes.Recipe;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.Map;

@Service
public class RecipeService {
    private final Map<Integer, Recipe> recipeDatabase;
    private int id;

    public RecipeService() {
        this.recipeDatabase = new HashMap<>();
        this.id = 1;
    }

    public Recipe getRecipe(int id) {
        if (recipeDatabase.containsKey(id)) {
            return recipeDatabase.get(id);
        }

        throw new ResponseStatusException(HttpStatus.NOT_FOUND);
    }

    public int setRecipe(Recipe recipe) {
        int idForNewRecipe = id;
        this.recipeDatabase.put(idForNewRecipe, recipe);
        id++;

        return idForNewRecipe;
    }
}
