package recipes.Recipe;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/recipe")
public class RecipeController {
    private final RecipeService rs;

    @Autowired
    public RecipeController(RecipeService rs) {
        this.rs = rs;
    }

    @PostMapping("/new")
    public Map<String, Integer> postRecipe(@RequestBody Recipe recipe) {
        int id = this.rs.setRecipe(recipe);
        return Map.of("id", id);
    }

    @GetMapping("/{id}")
    public Recipe getRecipe(@PathVariable int id) {
        return this.rs.getRecipe(id);
    }
}
