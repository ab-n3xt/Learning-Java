package recipes.Recipe;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/recipe")
public class RecipeController {
    private final RecipeService rs;

    @Autowired
    public RecipeController(RecipeService rs) {
        this.rs = rs;
    }

    @PostMapping("/new")
    public Map<String, Long> postRecipe(@Valid @RequestBody Recipe recipe) {
        long id = this.rs.setRecipe(recipe);
        return Map.of("id", id);
    }

    @GetMapping("/{id}")
    public Recipe getRecipe(@PathVariable long id) {
        return this.rs.getRecipe(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteRecipe(@PathVariable long id) {
        if (this.rs.deleteRecipe(id)) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updateRecipe(@PathVariable long id,
                                               @Valid @RequestBody Recipe recipe) {
        if (this.rs.updateRecipe(id, recipe)) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/search")
    public List<Recipe> searchRecipesByName(@RequestParam Map<String, String> name) {
        if (name.size() != 1) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        }

        if (name.containsKey("category"))
            return this.rs.getRecipesByCategory(name.get("category"));
        else if (name.containsKey("name"))
            return this.rs.getRecipesByName(name.get("name"));

        throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
    }
}
